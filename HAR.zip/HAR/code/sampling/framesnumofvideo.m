% Specify the folder containing your videos
videosFolder = 'D:\study\NTU CCA\machine vision\assignment1\EE6222 train and validate 2024\train\Walk';

% Get a list of all video files in the folder
videoFiles = dir(fullfile(videosFolder, '*.mp4')); % Assuming videos are in mp4 format

% Initialize a cell array to store frame information for each video
frameInfoCellArray = cell(length(videoFiles), 2);

% Iterate through each video
for i = 1:length(videoFiles)
    % Construct the full path to the current video
    videoPath = fullfile(videosFolder, videoFiles(i).name);

    % Create a VideoReader object
    videoObj = VideoReader(videoPath);

    % Get the duration and frame rate of the video
    duration = videoObj.Duration;
    frameRate = videoObj.FrameRate;

    % Calculate the number of frames to sample
    numFramesToSample = round(duration * frameRate);

    % Store frame information in the cell array
    frameInfoCellArray{i, 1} = videoFiles(i).name;
    frameInfoCellArray{i, 2} = numFramesToSample;

    % Optionally, you can perform further processing or analysis here
    % For example, you can extract frames using readFrame(), etc.
end

% Display the results
disp('Video Name   |   Number of Frames to Sample');
disp(frameInfoCellArray);
