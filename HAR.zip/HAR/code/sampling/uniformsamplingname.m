% Specify the path to the folder containing your videos
videosFolder = 'D:\study\NTU CCA\machine vision\assignment1\EE6222 train and validate 2024\validate';

% Get a list of all video files in the folder
videoFiles = dir(fullfile(videosFolder, '*.mp4')); % Assuming videos are in mp4 format

% Define the fixed interval for sampling frames
fixedInterval = 1;

% Define the desired number of frames to sample uniformly from each video
desiredNumFrames = 25;

% Create a folder to store the uniformly sampled frames
outputFolder = 'D:\study\NTU CCA\machine vision\assignment1\EE6222 train and validate 2024\validate\uniformsampling';
mkdir(outputFolder);

% Iterate through each video file
for i = 1:length(videoFiles)
    % Construct the full path to the current video
    videoPath = fullfile(videosFolder, videoFiles(i).name);

    % Create a VideoReader object
    videoObj = VideoReader(videoPath);

    % Get video information
    numFrames = videoObj.NumberOfFrames;

    % Calculate the fixed interval based on the desired number of frames
    fixedInterval = max(1, floor(numFrames / desiredNumFrames));

    % Extract the video name without the file extension
    [~, videoName, ~] = fileparts(videoFiles(i).name);

    % Create a folder for each video to store the uniformly sampled frames
    videoOutputFolder = fullfile(outputFolder, videoName);
    mkdir(videoOutputFolder);

    % Initialize the video player
    videoPlayer = vision.VideoPlayer;

    % Iterate through uniformly sampled frames and save them
    for frameIndex = 1:fixedInterval:(fixedInterval * desiredNumFrames)
        % Read the current frame
        currentFrame = read(videoObj, frameIndex);

        % Display the current frame in the video player
        step(videoPlayer, currentFrame);

        % Create a file name for the output image
        outputFileName = sprintf('%s_frame_%04d.jpg', videoName, frameIndex);

        % Save the frame as a JPG image in the video-specific folder
        imwrite(currentFrame, fullfile(videoOutputFolder, outputFileName));
    end

    % Release the video player
    release(videoPlayer);

    disp(['Uniformly sampling and saving frames for ' videoFiles(i).name ' completed.']);
end
