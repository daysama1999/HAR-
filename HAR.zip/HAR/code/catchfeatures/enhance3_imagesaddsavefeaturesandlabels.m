% Example usage:
parent_folder = 'D:\study\NTU CCA\machine vision\assignment1\EE6222 train and validate 2024\validate_result\uniformsampling'; % Specify the parent folder path containing subfolders with images

% Process each subfolder
subfolders = dir(parent_folder);
for i = 1:length(subfolders)
    if subfolders(i).isdir && ~strcmp(subfolders(i).name, '.') && ~strcmp(subfolders(i).name, '..')
        % Process images in the current subfolder
        subfolder_path = fullfile(parent_folder, subfolders(i).name);
        output_folder = fullfile(parent_folder, 'enhancebychangeposition', subfolders(i).name);
        process_images(subfolder_path, output_folder);
    end
end

function process_images(image_folder, output_folder)
    % Specify the reference mean and standard deviation
    reference_mean = [0.07, 0.07, 0.07];
    reference_std = [0.1, 0.09, 0.08];
    
    % Load pre-trained ResNet-50 model
    net = resnet50;

    % Create the output folder if it does not exist
    if ~exist(output_folder, 'dir')
        mkdir(output_folder);
    end

    % Read image files from the image folder
    image_files = dir(fullfile(image_folder, '*.jpg'));  % Get all jpg files in the image folder

    % Number of frames in the video
    num_frames = numel(image_files);

    % Initialize an array to store frame-level features
    frame_features = zeros(1000, num_frames); % Assuming 1000 features from the fc1000 layer
    labels = zeros(num_frames, 1);  % Initialize array to store labels
    video_label = ''; % Initialize video label

    % Loop through each frame to read, process features, and save normalized images
    for i = 1:num_frames
        % Read image for each frame
        image_file_path = fullfile(image_folder, image_files(i).name);
        frame = imread(image_file_path);

        % Normalize pixel values
        normalized_frame = normalize_frame(frame, reference_mean, reference_std, [0, 0, 0], [1, 1, 1]);

        % Perform bilateral filtering
        normalized_frame = imbilatfilt(normalized_frame);

        % Save the normalized and filtered image in the output folder
        [~, filename, ~] = fileparts(image_files(i).name);  % Extract filename without extension
        output_file_path = fullfile(output_folder, [filename '_normalized_and_filtered.jpg']);
        imwrite(normalized_frame, output_file_path);

        % Extract features using the pre-trained ResNet-50 model
        features = extract_features(net, normalized_frame);

        % Store the features for each frame
        frame_features(:, i) = features;

        % Extract activity from the filename and assign label
        labels(i) = map_activity_to_class(extract_activity_from_filename(image_file_path));
    end

    % Compute the total label for the video
    video_label = mode(labels);

    % Apply pooling (average) operation across all sampled frames
    video_features = mean(frame_features, 2);
    
    % Save video label and features to a MAT file
    [~, last_foldername, ~] = fileparts(image_folder);  % Extract the last word from the image folder path
    features_file_path = fullfile(output_folder, [last_foldername '_extracted_features.mat']);
    save(features_file_path, 'video_features', 'video_label');
end

function activity = extract_activity_from_filename(filename)
    % Extract activity from the filename
    [~, name, ~] = fileparts(filename);
    parts = split(name, '_');
    activity = lower(parts{1});  % Assuming the activity is the first part of the filename and converting to lowercase
end

function label = map_activity_to_class(activity)
    % Map activity labels to classes
    switch activity
        case {'jump', 'jump'}
            label = 1;
        case 'run'
            label = 2;
        case 'sit'
            label = 3;
        case 'stand'
            label = 4;
        case 'turn'
            label = 5;
        case 'walk'
            label = 6;
        otherwise
            label = -1; % Unknown label
    end
end

function normalized_frame = normalize_frame(frame, reference_mean, reference_std, target_mean, target_std)
    % Normalize pixel values of the frame to have zero mean and unit standard deviation
    normalized_frame = (double(frame) - repmat(reshape(reference_mean, [1, 1, numel(reference_mean)]), size(frame, 1), size(frame, 2))) ...
        ./ repmat(reshape(reference_std, [1, 1, numel(reference_std)]), size(frame, 1), size(frame, 2));

    % Adjust the normalization to achieve target mean and standard deviation
    target_mean = reshape(target_mean, [1, 1, numel(target_mean)]);
    target_std = reshape(target_std, [1, 1, numel(target_std)]);
    normalized_frame = (normalized_frame - mean(normalized_frame(:))) ./ std(normalized_frame(:)) .* target_std + target_mean;
end

function features = extract_features(net, frame)
    % Resize the frame to match the input size expected by the network
    frame = imresize(frame, [224, 224]);

    % Extract features from the 'fc1000' layer
    features = activations(net, frame, 'fc1000', 'OutputAs', 'columns');
    feature_dimensions = size(features);
    disp(['Feature dimensions: ' num2str(feature_dimensions)]);
end
