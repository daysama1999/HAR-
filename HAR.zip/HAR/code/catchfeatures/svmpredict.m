% Specify the path to the saved SVM model
model_path = 'D:\study\NTU CCA\machine vision\assignment1\result\UNIFORMSAMPLINGRESULT\enhancebyfilter3\trained_svm_model_randonsampling.mat';

% Load the trained SVM model
loaded_model = load(model_path);
svm_model = loaded_model.svm_model;

% Specify the path to the MAT file containing the new video features
new_features_path = 'D:\study\NTU CCA\machine vision\assignment1\EE6222 train and validate 2024\validate_result\uniformsampling\enhancebyfilter3\features\all_video.mat';

% Load the new video features
new_features_data = load(new_features_path);
new_video_features = new_features_data.all_video_features;

% Perform prediction using the loaded SVM model
predictions = predict(svm_model, new_video_features);

% Save the predictions to a MAT file
output_file_path = 'D:\study\NTU CCA\machine vision\assignment1\EE6222 train and validate 2024\validate_result\uniformsampling\enhancebyfilter3\features\enhancebyfilter3.mat';
save(output_file_path, 'predictions');
