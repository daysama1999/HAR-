% Example usage:
image_folder = 'D:\study\NTU CCA\machine vision\assignment1\result\RANDOMSAMPLINGRESULT\JUMP\Jump_8_2'; % Specify the folder path for reading images

% Check mean and standard deviation of the normalized images for each frame
check_mean_std(image_folder);

function check_mean_std(image_folder)
    % Number of frames in the video
    num_frames = 25;

    % Loop through each frame to read and check statistics
    for i = 1:num_frames
        % Read image for each frame
        image_file_path = fullfile(image_folder, sprintf('Jump_8_2_frame_%04d.jpg', i));
        frame = imread(image_file_path);

        % Normalize pixel values
        normalized_frame = double(frame) / 255; % Assuming pixel values are in the range [0, 255]

        % Calculate mean and standard deviation
        mean_value = mean(normalized_frame(:));
        std_value = std(normalized_frame(:));

        % Display mean and standard deviation for each frame
        disp(['Frame ', num2str(i), ':']);
        disp(['Mean: ', num2str(mean_value)]);
        disp(['Standard deviation: ', num2str(std_value)]);
        disp('------------------------');
    end
end
