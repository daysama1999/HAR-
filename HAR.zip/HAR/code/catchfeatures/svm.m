% Specify the path to the MAT file
mat_file_path = 'D:\study\NTU CCA\machine vision\assignment1\EE6222 train and validate 2024\validate_result\uniformsampling\enhancebyfilter3\features\all_video.mat';

% Load the extracted features MAT file
load(mat_file_path);

% Perform SVM classification using the extracted features
svm_model = svm_classification(all_video_features, all_video_labels);

% Save the trained SVM model to the same folder as the input MAT file
model_save_path = fileparts(mat_file_path); % ��ȡ����MAT�ļ����ļ���·��
save(fullfile(model_save_path, 'trained_svm_model_randonsampling.mat'), 'svm_model'); % ����ģ��

function svm_model = svm_classification(all_video_features, all_video_labels)
    % Check dimensions of input data
    disp(['Size of video_features: ', num2str(size(all_video_features))]);
    disp(['Size of video_label: ', num2str(size(all_video_labels))]);

    % Train the SVM classifier using one-vs-one coding
    svm_model = fitcecoc(all_video_features, all_video_labels);

    % Display SVM model details
    disp(svm_model);

    % You can continue with the rest of your classification workflow here
end
