% Load the extracted features MAT file
load('extracted_features.mat');

% Obtain or generate labels (replace this with your actual labels)
% Assuming you have 1000 samples with 2 classes (0 and 1)
num_samples = size(frame_features, 2); % Assuming frame_features is your feature matrix
labels = randi([0, 1], [num_samples, 1]); % Generate random labels for demonstration purposes

% Split the data into training and testing sets (if necessary)
% Assuming you have 80% training and 20% testing
train_ratio = 0.8;
num_train = round(train_ratio * num_samples);
train_features = frame_features(:, 1:num_train);
test_features = frame_features(:, num_train+1:end);
train_labels = labels(1:num_train);
test_labels = labels(num_train+1:end);

% Add label variables to the MAT file
save('extracted_features_with_labels.mat', 'frame_features', 'video_features', 'train_features', 'test_features', 'train_labels', 'test_labels');
